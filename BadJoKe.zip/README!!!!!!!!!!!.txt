______           _   ___       _   __     
| ___ \         | | |_  |     | | / /     
| |_/ / __ _  __| |   | | ___ | |/ /  ___ 
| ___ \/ _` |/ _` |   | |/ _ \|    \ / _ \
| |_/ / (_| | (_| /\__/ / (_) | |\  \  __/
\____/ \__,_|\__,_\____/ \___/\_| \_/\___|
                                          
                                          .exe
-------------------------------------------------------
Made by cyanmalware
It was created with C# and Assembly
This is my first gdi trojan, so don't be impressed. 
My channel: https://www.youtube.com/@cyanmalware
It is recommended to run from the Windows XP to 11.
(need .NET Framework 4.0)
So ENJOY!
-------------------------------------------------------

:(